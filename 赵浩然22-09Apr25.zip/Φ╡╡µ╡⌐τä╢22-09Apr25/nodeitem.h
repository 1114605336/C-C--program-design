typedef int serialNum;
typedef double price;
typedef char name;
typedef char position;
typedef char user;
typedef char classes;
typedef char date;
bool input_name(name *a);
bool input_serialNum(serialNum *a);
bool input_position(position *a);
bool input_user(user *a);
bool input_price(price *a);
bool input_class(classes *a);
bool input_date(date *a);
bool modify_name(name *a);
//bool modify_serialNum(serialNum *a);
bool modify_position(position *a);
bool modify_user(user *a);
bool modify_price(price *a);
bool modify_class(classes *a);
bool modify_date(date *a);


