#include <iostream>
#include "node.h"
using namespace std;
typedef struct ll{
	pdevice head;
}linklist,*plinklist;
void create_linklist(pdevice *a);
//bool delete_linklist(plinklist a);  //emmm删库？
//pdevice search_linklist(plinklist a);
