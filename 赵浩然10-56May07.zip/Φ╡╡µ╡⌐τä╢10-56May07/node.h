#include "nodeitem.h"
//增加节点，删除节点，展示节点
void insert_book(pbook a);
void insert_reader(preader a);
void delete_book(pbook a);
void delete_reader(preader a);
void display_book(pbook a);
void display_reader(preader a);

