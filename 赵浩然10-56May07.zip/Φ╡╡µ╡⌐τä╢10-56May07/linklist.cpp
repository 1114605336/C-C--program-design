#include "linklist.h"
bool create_booklinklist(pbook *head){
	(*head)=(pbook)malloc(sizeof(book));
	(*head)->next=NULL;
	if(!(*head)){
		return false;
	}
	else{
		return true;
	}
}
bool create_readerlinklist(preader *head){
	(*head)=(preader)malloc(sizeof(reader));
	(*head)->next=NULL;
	if(!(*head)){
			return false;
		}
		else{
			return true;
		}
}
bool search_book_name(pbll a,char name[]){
	pbook t;
	t=a->head;
	while(t){
		if(!strcmp(t->name,name)){
			display_book(t);
			break;
		}
		t=t->next;
	}
	if(t==NULL){
		return false;
	}
	else{
		return true;
	}
}
bool search_book_serialNum(pbll a,int serial){
	pbook t;
	t=a->head;
	while(t){
		if(t->serialNum==serial){
			display_book(t);
			break;
		}
		t=t->next;
	}
	if(t==NULL){
			return false;
		}
		else{
			return true;
		}
}
bool search_book_author(pbll a,char author[]){
	int flag=0;
	pbook t;
	t=a->head;
	while(t){
		if(!strcmp(t->author,author)){
			display_book(t);
			flag++;
		}
		t=t->next;
	}
	if(flag==0){
		return false;
	}
	else{
		return true;
	}
}
bool search_book_print(pbll a,char print[]){
	int flag=0;
	pbook t;
	t=a->head;
	while(t){
		if(!strcmp(t->print,print)){
			display_book(t);
			flag++;
		}
		t=t->next;
	}
	if(flag==0){
		return false;
	}
	else{
		return true;
	}
}
bool search_reader(prll a,char bookname[]){
	preader t;
	t=a->head;
	while(t){
		if(!strcmp(t->bookname,bookname)){
			display_reader(t);
			break;
		}
		t=t->next;
	}
	if(t==NULL){
		return false;
	}
	else{
		return true;
	}
}

