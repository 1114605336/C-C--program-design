#include "node.h"
void insert_book(pbook a){
	a->next=(pbook)malloc(sizeof(book));
	a->next->next=NULL;
}
void insert_reader(preader a){
	a->next=(preader)malloc(sizeof(reader));
	a->next->next=NULL;
	a->next->bookname[0]=0;
}
void delete_book(pbook a){
	pbook t;
	t=a->next->next;
	free(a->next);
	a->next=t;
}
void delete_reader(preader a){
	preader t;
	t=a->next->next;
	free(a->next);
	a->next=t;
}
void display_book(pbook a){
	printf("The name is %s\n",a->name);
	printf("The serialNum is %d\n",a->serialNum);
	printf("The number is %d\n",a->number);
	printf("The price is %f\n",a->price);
	printf("The class is %s\n",a->classes);
	printf("The date is %s\n",a->date);
	printf("The author is %s\n",a->author);
	printf("The print is %s\n",a->print);
}
void display_reader(preader a){
	printf("The name is %s\n",a->name);
	printf("The department is %s\n",a->department);
	printf("The ID is %ld\n",a->ID);
	printf("The bookname is %s\n",a->bookname);
}
