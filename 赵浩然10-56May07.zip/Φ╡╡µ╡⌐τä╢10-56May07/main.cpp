#include "linklist.h"
//书籍的录入，修改，删除，书籍的按名称、编号、作者、出版社查询，书籍被谁借走
int main(int argc, char *argv[]) {
	bll a;
	pbook n1;   //指向当前的最后一个
	preader n2; //指向当前的最后一个
	rll b;
	int bflag=0,rflag=0,modname,control,searchint,fault;
	char name[20],bookname[20],seaby[10],search[20],control1[20],control2[20];
	pbook tmod,td;
	preader tmod1,td1;
	while(1){
		if(bflag==0){
			printf("There is no book,you should input a book\n");
			if(create_booklinklist(&(a.head))){
				printf("Input starts\n");
				n1=a.head;
				printf("Please input the name\n");
				i_m_string(n1->name);
				printf("Please input the serialNum\n");
				i_m_int(&(n1->serialNum));
				printf("Please input the number\n");
				i_m_int(&(n1->number));
				printf("Please input the price\n");
				i_m_float(&(n1->price));
				printf("Please input the class\n");
				i_m_string(n1->classes);
				printf("Please input the date\n");
				i_m_string(n1->date);
				printf("Please input the author\n");
				i_m_string(n1->author);
				printf("Please input the print\n");
				i_m_string(n1->print);
				printf("Input succeeds\n");
				bflag=1;
			}
			else{
				printf("Input fails\n");
				exit(EXIT_FAILURE);
			}
		}
		if(rflag==0){
			printf("There is no reader,you should input a reader\n");
			if(create_readerlinklist(&(b.head))){
				n2=b.head;
				printf("Input starts\n");
				printf("Please input the name\n");
				i_m_string(n2->name);
				printf("Please input the department\n");
				i_m_string(n2->department);
				printf("Please input the ID\n");
				i_m_long(&(n2->ID));
				printf("Please input the book\n");
				i_m_string(n2->bookname);
				printf("Input succeeds\n");
				rflag=1;
				n2=b.head;
				continue;
			}
			else{
				printf("Input fails\n");
				exit(EXIT_FAILURE);
			}
		}
		if(bflag&&rflag){
			printf("If you want to do something about book,please input 1\nIf you want to do something about reader,please input 2\n");
			scanf("%d",&control);
			getchar();
			if(control==1){
				printf("You can input,modify,delete,search,quit\n");
				printf("Please input what you want to do:input,modify,delete,search,quit\n");
				gets(control1);
				if(!strcmp(control1,"input")){
					printf("Input starts\n");
					insert_book(n1);
					n1=n1->next;    //更新n1
					printf("Please input the name\n");
					i_m_string(n1->name);
					printf("Please input the serialNum\n");
					i_m_int(&(n1->serialNum));
					printf("Please input the number\n");
					i_m_int(&(n1->number));
					printf("Please input the price\n");
					i_m_float(&(n1->price));
					printf("Please input the class\n");
					i_m_string(n1->classes);
					printf("Please input the date\n");
					i_m_string(n1->date);
					printf("Please input the author\n");
					i_m_string(n1->author);
					printf("Please input the print\n");
					i_m_string(n1->print);
					printf("Input ends\n");
				}
				else if(!strcmp(control1,"modify")){
					printf("Modify starts\n");
					printf("Please input the the book's name\n");
					gets(name);
					tmod=a.head;
					while(tmod){
						if(!strcmp(tmod->name,name)){
							break;
						}
						tmod=tmod->next;
					}
					if(tmod==NULL){
						printf("This book is not existing\n");
					}
					else{
						printf("Please enter the corresponding number:name(1),serialNum(2),number(3),price(4),class(5),date(6),author(7),print(8)\n");
						scanf("%d",&modname);
						getchar();
						switch (modname){   
							case 1:
								printf("Please input the name\n");
								i_m_string(tmod->name);
								break;
							case 2:
								printf("Please input the serialNum\n");
								i_m_int(&(tmod->serialNum));
								break;
							case 3:
								printf("Please input the number\n");
								i_m_int(&(tmod->number));
								break;
							case 4:
								printf("Please input the price\n");
								i_m_float(&(tmod->price));
								break;
							case 5:
								printf("Please input the class\n");
								i_m_string(tmod->classes);
								break;
							case 6:
								printf("Please input the date\n");
								i_m_string(tmod->date);
								break;
							case 7:
								printf("Please input the author\n");
								i_m_string(tmod->author);
								break;
							case 8:
								printf("Please input the print\n");
								i_m_string(tmod->print);
								break;
						}
					}
					printf("Modify ends\n");
				}
				else if(!strcmp(control1,"delete")){
					td=a.head;
					printf("Delete starts\n");
					printf("Please input the book's name\n");
					gets(bookname);
					if(td->next==NULL){
						printf("Just one book reminded,you can't delete it\n");
						continue;
					}
					if(!strcmp(td->name,bookname)){
						a.head=a.head->next;
						free(td);
						printf("Delete ends\n");
						continue;
					}
					while(td){
						if(!strcmp((td->next)->name,bookname)){
							break;
						}
						td=td->next;
					}
					if(td==NULL){
						printf("This book is not existing\n");
					}
					else{
						delete_book(td);
					}
					printf("Delete ends\n");
					break;
				}
				else if(!strcmp(control1,"search")){
					printf("Search starts\n");
					printf("Please input what do you want to search by:name,serialNum,author,print\n");
					gets(seaby);
					if(!strcmp(seaby,"name")){
						printf("Please input the book's name\n");
						gets(search);
						fault=search_book_name(&a,search);
						if(!fault){
							printf("This book is not existing\n");
						}
						else{
							printf("Search succeeds\n");
							preader ttt=b.head;
							while(ttt){
								if(!strcmp(ttt->bookname,search)){
									printf("The leader is %s\n",ttt->name);
								}
								ttt=ttt->next;
							}
							if(!ttt){
								printf("No leader\n");
							}			
						}
					}
					else if(!strcmp(seaby,"serialNum")){
						printf("Please input the book's serialNum\n");
						scanf("%d",&searchint);
						fault=search_book_serialNum(&a,searchint);
						if(!fault){
							printf("This book is not existing\n");
						}
						else{
							printf("Search succeeds\n");
						}
					}
					else if(!strcmp(seaby,"author")){
						printf("Please input the book's author\n");
						gets(search);
						fault=search_book_author(&a,search);
						if(!fault){
							printf("This book is not existing\n");
						}
						else{
							printf("Search succeeds\n");
						}
					}
					else if(!strcmp(seaby,"print")){
						printf("Please input the book's print\n");
						gets(search);
						fault=search_book_print(&a,search);
						if(!fault){
							printf("This book is not existing\n");
						}
						else{
							printf("Search succeeds\n");
						}
					}
					else{
						printf("You input wrong command\n");
					}
				}
			else if(!strcmp(control1,"quit")){
				printf("You quit this program\n");
				exit(EXIT_SUCCESS);
			}
			else{
				printf("You input the wrong command\n");
			}
		}
		else{
			printf("You can input,modify,delete,quit\n");
			printf("Please input what you want to do:input,modify,delete,quit\n");
			gets(control2);
			if(!strcmp(control2,"input")){
				printf("Input starts\n");
				insert_reader(n2);
				n2=n2->next;    //更新n2
				printf("Please input the name\n");
				i_m_string(n2->name);
				printf("Please input the department\n");
				i_m_string(n2->department);
				printf("Please input the ID\n");
				i_m_long(&(n2->ID));
				printf("Please input the book\n");
				i_m_string(n2->bookname);
				printf("Input ends\n");
			}
			else if(!strcmp(control2,"modify")){
				printf("Modify starts\n");
				printf("Please input the the reader's name\n");
				gets(name);
				tmod1=b.head;
				while(tmod){
					if(!strcmp(tmod1->name,name)){
						break;
					}
					tmod1=tmod1->next;
				}
				if(tmod1==NULL){
					printf("This reader is not existing\n");
				}
				else{
					printf("Please enter the corresponding number:name(1),department(2),ID(3),book(4)\n");
					scanf("%d",&modname);
					getchar();
					switch (modname){   
						case 1:
							printf("Please input the name\n");
							i_m_string(tmod1->name);
							break;
						case 2:
							printf("Please input the department\n");
							i_m_string(tmod1->department);
							break;
						case 3:
							printf("Please input the ID\n");
							i_m_long(&(tmod1->ID));
							break;
						case 4:
							printf("Please input the book\n");
							if(!(tmod1->bookname)[0]){
								i_m_string(tmod1->bookname);
								break;
							}
							else{
								printf("This reader has leaded a book\n");
								break;
							}
					}
				}
				printf("Modify ends\n");
			}
			else if(!strcmp(control2,"delete")){
				td1=b.head;
				printf("Delete starts\n");
				printf("Please input the reader's name\n");
				gets(name);
				if(td1->next==NULL){
					printf("Just one reader remained,you can't delete\n");
					continue;
				}
				if(!strcmp(td1->name,name)){
					b.head=b.head->next;
					free(td1);
					continue;
				}
				while(td1){
					if(!strcmp(td1->next->name,bookname)){
						break;
					}
					td1=td1->next;
				}
				if(td1==NULL){
					printf("This book is not existing\n");
				}
				else{
					delete_reader(td1);
				}
				printf("Delete ends\n");
				break;
			}
			else if(!strcmp(control2,"quit")){
				printf("You quit this program\n");
				exit(EXIT_SUCCESS);
			}
			else{
				printf("You input the wrong command\n");
			}
		}
	}
}
return 0;
}

