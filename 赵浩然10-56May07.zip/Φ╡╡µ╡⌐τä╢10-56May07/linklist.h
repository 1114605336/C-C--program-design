#include "node.h"
typedef struct booklinklist{
	pbook head;
}bll,*pbll;
typedef struct readerlinklist{
	preader head;
}rll,*prll;
//链表的创建，搜索
bool create_booklinklist(pbook *head);
bool create_readerlinklist(preader *head);
bool search_book_name(pbll a,char name[]);
bool search_book_serialNum(pbll a,int serial);
bool search_book_author(pbll a,char author[]);
bool search_book_print(pbll a,char print[]);
bool search_reader(prll a,char bookname[]);

