#include "nodeitem.h"
void i_m_int(int *a){
	scanf("%d",a);
	getchar();
}
void i_m_float(float *a){
	scanf("%f",a);
	getchar();
}
void i_m_string(char *a){
	gets(a);
}
void i_m_long(long *a){
	scanf("%ld",a);
	getchar();
}
