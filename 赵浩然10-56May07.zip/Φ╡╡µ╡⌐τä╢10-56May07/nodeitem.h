#include <cstdio>
#include <cstring>
#include <cstdlib>
using namespace std;
typedef struct book{
char name[20];//图书名称
int serialNum;//图书编号
int number;//图书数量
float price;//图书价格
char classes[20];// 图书种类(如：教材、著作等)
char date[20];//图书出版日期，如20090101等
char author[20];//图书作者
char print[20];//出版社
struct book *next;
}book,*pbook;
typedef struct reader{
char name[20];//姓名
char department[20];//所在学院
long ID;//读者编号
char bookname[20];//所借图书名称
struct reader *next;
}reader,*preader;
//对整数，单精度，字符串，长整型的录入，修改
void i_m_int(int *a);
void i_m_float(float *a);
void i_m_string(char *a);
void i_m_long(long *a);